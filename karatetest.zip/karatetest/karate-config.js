function fn() {
    var config = {
        guid: '',
    }
    return config;
}